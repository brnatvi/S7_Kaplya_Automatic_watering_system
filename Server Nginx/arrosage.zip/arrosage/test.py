import sys

arg1 = sys.argv[1]
arg2 = sys.argv[2]

result = arg1 + " " + arg2

print(result)