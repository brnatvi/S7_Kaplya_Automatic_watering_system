<ul class="navbar">
    <li><a href="index.php">Home</a></li>
    <li><a href="modify_plants.php">Modify plants</a></li>
    <li><a href="manual_control.php">Manual control</a></li>
    <li><a href="logs.php">Logs</a></li>
</ul>

<br>
<div class="line"></div>
